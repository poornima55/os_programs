
/* main.c */

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include "prod_cons_MT.h"


struct Thread_info *prod_thread_info[10000]; //structures to be passed to each producer thread

struct Thread_info *cons_thread_info[10000];//structures to be passed to each consumer thread

pthread_t prod_tid[10000],cons_tid[10000];       //Thread ID
pthread_attr_t attr; //Set of thread attributes



int BUFFER_SIZE;
struct monitorDatatype monitor;

void initializeData() {

   /* Create the mutex lock */
   pthread_mutex_init(&(monitor.mutex), NULL);
   pthread_cond_init(&(monitor.not_full),NULL);
   pthread_cond_init(&(monitor.not_empty),NULL);


   /* Get the default attributes */
   pthread_attr_init(&attr);

   /* init buffer */
   monitor.rear = -1;
   monitor.front = 0;
   monitor.counter = 0;
}



int main(int argc, char *argv[]) {
   /* Loop counter */
   int i;
   
   /* Verify the correct number of arguments were passed in */
   if(argc != 4) {
      fprintf(stderr, "USAGE:./main.out <INT> <INT> <INT>\n");
   }

   srand(time(0)); //system time used as seed for rand() function
   BUFFER_SIZE= atoi(argv[1]); /* Time in seconds for main to sleep */
   int numProd = atoi(argv[2]); /* Number of producer threads */
   int cons_no = atoi(argv[3]); /* Number of consumer threads */

   monitor.buffer = (int*) malloc(sizeof(int)*BUFFER_SIZE);
   if(monitor.buffer==NULL)
   {
	   printf("Error in allocating buffer\n");
	   return 1;
   }
   /* Initialize the app */
   initializeData();

   /* Create the producer threads */
   for(i = 0; i < numProd; i++) {
      /* Create the thread and initialize the structure to be passed to each thread*/
	   prod_thread_info[i] = (struct Thread_info*)malloc(sizeof(struct Thread_info));
	   prod_thread_info[i]->id = i; 
	   prod_thread_info[i]->count = 2*BUFFER_SIZE;
	   printf("Main: started producer %d\n",i);
      	   pthread_create(&prod_tid[i],&attr,producer,(void*)prod_thread_info[i]);
    }

    int total_values = 2*BUFFER_SIZE*numProd;
    int cons_no_org = cons_no;
    int cnt= total_values/cons_no_org;
    int rem_values = total_values;

    /*Create the consumer threads and initialize the structure to be passed to each consumer thread*/
    for(i=0;i<cons_no_org;i++)
    {


		        cons_thread_info[i] = (struct Thread_info*)malloc(sizeof(struct Thread_info));
			//cnt =  total_values/cons_no;
			if(i<cons_no_org-1)
			{
				cons_thread_info[i]->count = cnt;
			}
			else
			{
				cons_thread_info[i]->count = rem_values;//last thread will handle the remaining 
			}
			cons_thread_info[i]->id = i;
			//thread_info->size = Buffer_size;
			printf("Main:started consumer %d\n",i);
			pthread_create(&cons_tid[i],&attr,consumer,(void*)cons_thread_info[i]);
			rem_values = rem_values-cnt;
		        
    }


  /* Sleep for the specified amount of time in milliseconds */
   //sleep(30);

    /*wait for all producer threads to complete*/
   for(i=0;i<numProd;i++)
   {
	   pthread_join(prod_tid[i],NULL);
	   printf("Main:producer %d joined\n",i);
	   free(prod_thread_info[i]);
   }
   /*wait for all consumer threads to complete*/
   for(i=0;i<cons_no_org;i++)
   {
	   pthread_join(cons_tid[i],NULL);
  	   printf("Main:consumer %d joined\n",i);
	   free(cons_thread_info[i]);
   }
 
   /* Exit the program */
   printf("Main:program completed\n");

   /*Delete the attribute*/
   pthread_attr_destroy(&attr);
   /* Delete the mutex lock and conditional variables*/
   pthread_mutex_destroy(&(monitor.mutex));
   pthread_cond_destroy(&(monitor.not_full));
   pthread_cond_destroy(&(monitor.not_empty));

   /*free the buffer*/
   free(monitor.buffer);

   exit(0);
}
