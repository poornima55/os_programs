#include<stdlib.h>
#include<pthread.h>
#include<stdio.h>
#include<unistd.h>
#include<time.h>
#include "prod_cons_MT.h"

#define TRUE 1

extern int BUFFER_SIZE;


extern struct monitorDatatype monitor; //monitor variable declared as extern and will be initialized in the main

/* Producer Thread */
void *producer(void *param) {
   buffer_item item;
   struct Thread_info *my_info= (struct Thread_info*)param;// the structure variable passed to the thread
   int temp_count = 0;  //initialize the count of produced values to 0
   printf("P%d:Producing %d values\n",my_info->id,my_info->count);
   while(temp_count < my_info->count) {

      
      /* generate a random number */
      item = rand()%11;

      /* acquire the mutex lock */
      pthread_mutex_lock(&(monitor.mutex));

      if((monitor.counter) == BUFFER_SIZE){

       printf("P%d:Blocked due to full buffer\n",my_info->id);
       pthread_cond_wait(&(monitor.not_full),&(monitor.mutex));
       printf("P%d:Done waiting on full buffer\n",my_info->id);
       }

      else
	{
	  	
		if((monitor.rear== BUFFER_SIZE-1))
		{
			(monitor.rear)= -1;
		}
		(monitor.rear)=(monitor.rear)+1; //update the 'rear' variable to maintain the queue
		monitor.buffer[monitor.rear] = item;//produced values are added to the rear of the queue
		(monitor.counter)=(monitor.counter)+1; //increment the counter
		printf("P%d: Writing %d to position %d\n",my_info->id, item,monitor.rear); 
      	 	temp_count++;//increment the count of values produced by the specific producer
	}
       pthread_cond_signal(&(monitor.not_empty));

      /* release the mutex lock */
      pthread_mutex_unlock(&(monitor.mutex));
        }
   printf("P%d:Exiting\n",my_info->id);//producer thread will exit after producing 2*buff_size values
   pthread_exit(0);
}



/* Consumer Thread */
void *consumer(void *param) {
   buffer_item item;
   struct Thread_info *my_info= (struct Thread_info*)param;//take the structure variable passed to the thread
   int temp_count = 0;//initialize the count of consumed values to 0
   printf("C%d:Consuming %d values\n",my_info->id,my_info->count);
   while(temp_count<my_info->count) {
    
      /* aquire the mutex lock */
      pthread_mutex_lock(&(monitor.mutex));
      if((monitor.counter)==0)
      {
	  printf("C%d:Blocked due to empty buffer\n",my_info->id);
      	  pthread_cond_wait(&(monitor.not_empty),&(monitor.mutex));
	  printf("C%d:Done waiting on empty buffer\n",my_info->id);

       }

      else{
        	item = monitor.buffer[monitor.front];//item in the front of the queue is read
		printf("C%d:Reading %d from position %d\n",my_info->id, item,monitor.front);

		(monitor.front)= (monitor.front)+1;//updating the front of the queue
		if((monitor.front)==BUFFER_SIZE)
		{
			monitor.front = 0;
		}
		monitor.counter = (monitor.counter)-1;//decrement the counter variable used for the queue status
       		temp_count++;//increment the count of values consumed by the specific thread
      }
      pthread_cond_signal(&(monitor.not_full));//signal that the queue is not full
  
      /* release the mutex lock */
      pthread_mutex_unlock(&(monitor.mutex));

     }
   printf("C%d:Exiting\n",my_info->id);
   pthread_exit(0);
}


