struct Thread_info
{
	int id;
	int count;
	
};


typedef int buffer_item;

struct monitorDatatype{
		/* The mutex lock */
		pthread_mutex_t mutex;

		pthread_cond_t not_full;
		pthread_cond_t not_empty;

		/* the buffer */
		int *buffer;

		/* buffer counter */
		int rear,front,counter;

};



extern void *producer(void *param); /* the producer thread */
extern void *consumer(void *param); /* the consumer thread */


