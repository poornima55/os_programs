#include<stdio.h>
#include"sched_sim.h"
#include<stdlib.h>
#include<unistd.h>
#include <errno.h>
#include <string.h>

struct Process_info process[10000];
int size;

struct PriorityQ_node *Priority_head = NULL; //priority queue head and tail
struct PriorityQ_node *Priority_last = NULL;
struct Priorityjob_Q *PriorityjobQ_head = NULL;  //job queue  head and tail
struct Priorityjob_Q *PriorityjobQ_last =  NULL;

struct proc_summary priority_summary[10000]; 

int priority_sequence[10000];
int p1;



struct  FifoQ_node *fifo_head = NULL; //fifo queue head and tail
struct  FifoQ_node *fifo_last = NULL;
struct fifojob_Q *fifojobQ_head = NULL;  //job queue  head and tail
struct fifojob_Q *fifojobQ_last =  NULL;

struct proc_summary fcfs_summary[10000];
int fcfs_sequence[10000];
int p2;

struct sjfQ_node *sjf_head = NULL; //sjf q queue head and tail
struct sjfQ_node *sjf_last = NULL;
struct sjfjob_Q *sjfjobQ_head = NULL;  //job queue  head and tail
struct sjfjob_Q *sjfjobQ_last = NULL;


struct proc_summary sjf_summary[10000];
int sjf_sequence[10000];

struct  RRQ_node *rr_head = NULL; //round robin  queue head and tail
struct  RRQ_node *rr_last = NULL;
struct rrjob_Q *rrjobQ_head = NULL;  //job queue  head and tail
struct robin_Q *rr_node = NULL;


int consecutive_iter_rr[10000] ={0,};
struct proc_rrsummary rr_summary[10000]; 
int sequence_rr[10000];



int new_member =0;
//struct Process_info process[10000];

struct stcfQ_node *stcf_head = NULL; //stcf queue head and tail
struct stcfQ_node *stcf_last = NULL;
struct stcfjob_Q *stcfjobQ_head = NULL;  //job queue  head and tail
int stcf_sequence[10000];

int consecutive_iter_stcf[10000] ={0,};

struct proc_stcfsummary stcf_summary[10000];

int main (int argc, char** argv )
{

   if(argc<4)
   {
	   printf("Enter the arguments properly\n");
	   printf("Usage : <arg1 : input file>, <arg2 : output file>, <arg3: timestamp>\n");
	   return 1;
   }

   char input_file[100]={'\0',};
   char output_file[100]={'\0',};


   int timestamp = (atoi)(argv[3]);

   strcpy(input_file,argv[1]);

   getProcessinfo(input_file);

   int i =0;
   
   FILE *file2 = NULL;
   strcpy(output_file,argv[2]);

   
   file2 = fopen(output_file,"w+");
  if(file2==NULL)
  {
          printf("file cannot be opened (%s)\n", strerror (errno));
          return 1;
  }	
 /* starting fcfs scheduling*/
   struct run_queue *fifo_run_Q = calloc(1,sizeof(*fifo_run_Q));
  
   if(fifo_run_Q==NULL)
   {
	   printf("Error in allocating memeory\n");
	   return 1;
   }


   for(i=0;i<size;i++)
   {
	   insert_node_fifo(&fifo_head,process[i]);     //add the processes to the priority queue

    }


  // display_queue_fifo(&head);		   

   int fifo_time = 0;

   int fifo_sched_done = 0;


   int fifo_CPU_load = 0;


   int fifo_context_switches =0;

   int fifo_execution_delay = 0;
  
   int total_wait_fcfs = 0;
   int total_turnaround_fcfs =0; 

   fprintf(file2,"****FCFS Scheduling Summary****\n");

   while(!fifo_sched_done)
   {
	   
	  
	   addnode_at_arrival_fifo(fifo_time,&fifojobQ_head,&fifo_head);  //adding processes to the job queue as they arrive 

	   if(fifo_time%timestamp==0)
 
           fprintf(file2,"Time: %d\n",fifo_time);


         
          if(fifo_CPU_load)
	  {

                 if(fifo_execution_delay == 0)
	          {
		  	fifo_run_Q->burst_time = fifo_run_Q->burst_time -1;
			 if(fifo_time%timestamp==0)
			{
			fprintf(file2,"Process %d is running in the CPU\t",fifo_run_Q->id);
               		fprintf(file2,"(remaining CPU burst = %d)\n",fifo_run_Q->burst_time);
                 	}
		   }

		  else
		  {
			  fifo_execution_delay = 0;
		  }

          
                  if(fifo_run_Q->burst_time == 0)
		  {
			  if(fifo_time%timestamp==0)
 
                          fprintf(file2,"Finishing process %d\n",fifo_run_Q->id);
			 
			  fcfs_summary[fifo_run_Q->id].turn_around_time = fifo_time - get_arrivaltime_fifo(fifo_run_Q->id,&fifo_head);

                   	  delete_node_fifo(&fifo_head,fifo_run_Q->id);    //remove node from the  Priority queue
			  delete_jobQnode_fifo(&fifojobQ_head,fifo_run_Q->id);

			  fifo_CPU_load = 0;
		  }
	  }
	 if(fifojobQ_head!=NULL && fifo_CPU_load == 0)
	  {
		 
		  load_process_fifo(fifo_run_Q, &fifojobQ_head); //load  the higher priority process to CPU
		  fcfs_sequence[p2++] = fifo_run_Q->id;

		  fifo_context_switches++;
		  fcfs_summary[fifo_run_Q->id].waiting_time = fifo_time- get_arrivaltime_fifo(fifo_run_Q->id,&fifo_head);
		  fcfs_summary[fifo_run_Q->id].proc_id = fifo_run_Q->id;
		 if(fifo_time%timestamp==0)
		{
		  fprintf(file2,"Loading process %d\t",fifo_run_Q->id);
		  fprintf(file2,"(CPU burst = %d)\n",fifo_run_Q->burst_time);

		}
		 fifo_CPU_load = 1;

		 fifo_execution_delay = 1;

	  }


	 if(fifo_time%timestamp==0)
	{
          if(fifojobQ_head!=NULL)
		//display_jobqueue_fifo(&fifojobQ_head);
	  {
		struct fifojob_Q  *current_fifo = fifojobQ_head;
		fprintf(file2,"Ready Queue: ");
		while(current_fifo!=NULL && current_fifo->next!=NULL)
		{
			fprintf(file2,"%d-> ",current_fifo->pid);
			current_fifo = current_fifo->next;
		}
		if(current_fifo!=NULL)
        	fprintf(file2,"%d \n",current_fifo->pid);
	  }



	  else
		  fprintf(file2,"Ready Queue :empty\n");
	}
	
	 if(isempty_fifo(&fifo_head) && fifo_CPU_load == 0)
	 {
			 fifo_sched_done = 1;        //priority queue is empty, all processes got scheduled
	 }
	
	
	fifo_time++;

	 if(fifo_execution_delay == 1)
		 fifo_execution_delay = 0;


   }

  fprintf(file2,"*******************************************\nFCFS Summary(WT=wait time, TT = turnaround time):\n");
  fprintf(file2,"PID\t WT\t TT\n");

  for(int t=0;t<size;t++)
  {	  
  	fprintf(file2,"%d\t%d\t%d\t\n",t,fcfs_summary[t].waiting_time,fcfs_summary[t].turn_around_time);
  
	total_wait_fcfs+= fcfs_summary[t].waiting_time;
	total_turnaround_fcfs+= fcfs_summary[t].turn_around_time;
  }

  float avg_waitingtime_fcfs = ((float)total_wait_fcfs)/size;
  float avg_turnaround_fcfs = ((float)total_turnaround_fcfs)/size;

  fprintf(file2,"Avg waiting time is %f and avg turnaround time is %f\n", avg_waitingtime_fcfs,avg_turnaround_fcfs);
  fprintf(file2,"Process sequence:\t");
  int t13 = 0;
  for(t13=0;t13<p2-1;t13++)
  {	  
  	fprintf(file2,"%d->\t", fcfs_sequence[t13]);
  }
	fprintf(file2,"%d\n", fcfs_sequence[t13]);

 fprintf(file2,"\n Context Switches: %d\n",fifo_context_switches);

 /*starting sjf scheduling*/

   int sjf_time = 0;
  
   //sort_priority(process);
 
   struct run_queue *sjf_run_Q = calloc(1,sizeof(*sjf_run_Q));
   if(sjf_run_Q==NULL)
   {
	   printf("Error in allocating memeory\n");
	   return 1;
   }

   for(i=0;i<size;i++)
   {
	   insert_node_sjf(&sjf_head,process[i]);     //add the processes to the priority queue

    }

 int total_wait_sjf = 0;
 int total_turnaround_sjf =0; 

 fprintf(file2,"*****SJF Scheduling****\n");

   struct sjfjob_Q *sjfjobQ_last =  NULL;


   int sjf_sched_done = 0;


   int sjf_CPU_load = 0;

   int context_switches_sjf = 0;

   int sjf_execution_delay = 0;

   int c1= 0;
      
   while(!sjf_sched_done)
   {
	

       	   addnode_at_arrival_sjf(sjf_time,&sjfjobQ_head,&sjf_head);  //adding processes to the job queue as they arrive 

           if(sjf_time%timestamp==0)
	   fprintf(file2,"Time: %d\n",sjf_time);

	  if(sjf_CPU_load)
	  {

		 
		  if(sjf_execution_delay == 0)
		  {
		  	sjf_run_Q->burst_time = sjf_run_Q->burst_time -1;
                        if(sjf_time%timestamp==0)
                        {
	       	        fprintf(file2,"Process %d is running in the CPU\t",sjf_run_Q->id);
			fprintf(file2,"(remaining CPU burst = %d)\n",sjf_run_Q->burst_time);
			}


		  }

		  else
		  {
			 sjf_execution_delay = 0;
		  }

		 if(sjf_run_Q->burst_time == 0)
		  {
 			 if(sjf_time%timestamp==0)

                         fprintf(file2,"Finishing process %d\n", sjf_run_Q->id);
                          
			  sjf_summary[sjf_run_Q->id].turn_around_time = sjf_time - get_arrivaltime_sjf(sjf_run_Q->id,&sjf_head);


			  delete_node_sjf(&sjf_head,sjf_run_Q->id);    //remove node from the  Priority queue

			  
			  sjf_CPU_load = 0;
		  }
	  }
	  
	  if(sjfjobQ_head!=NULL && sjf_CPU_load == 0)
	  {
		 load_process_sjf(sjf_run_Q, &sjfjobQ_head); //load  the higher priority process to CPU
		sjf_sequence[c1++] = sjf_run_Q->id;

                context_switches_sjf++;

		 sjf_summary[sjf_run_Q->id].proc_id = sjf_run_Q->id;
		 sjf_summary[sjf_run_Q->id].waiting_time = sjf_time - get_arrivaltime_sjf(sjf_run_Q->id,&sjf_head);
		 if(sjf_time%timestamp==0)
 		{
		 fprintf(file2,"Loading Process %d\t",sjf_run_Q->id);
		 fprintf(file2,"(CPU burst = %d)\n",sjf_run_Q->burst_time);
		}
		 sjf_CPU_load = 1;

		 sjf_execution_delay =  1;


	  }

    if(sjf_time%timestamp==0)
   {
    if(sjfjobQ_head!=NULL)
	   {
	   	arrange_jobqueue_sjf(&sjfjobQ_head);
		fprintf(file2,"Ready queue:\n");
		struct sjfjob_Q *current_sjf = sjfjobQ_head;
		while(current_sjf!=NULL && current_sjf->next!=NULL)
		{
			fprintf(file2,"%d -> ",current_sjf->pid);
			current_sjf = current_sjf->next;
		}

		if(current_sjf!=NULL)
		fprintf(file2,"%d \n", current_sjf->pid);
	   }

	 	  else
		   fprintf(file2,"Ready Queue: empty\n");
	}
     
    if(isempty_sjf(&sjf_head)&& sjf_CPU_load == 0)
	 {
			 sjf_sched_done = 1;        //priority queue is empty, all processes got scheduled
	 }
	
	 sjf_time++;

	 if(sjf_execution_delay == 1)
		sjf_execution_delay = 0;


   }

  fprintf(file2,"*******************************************\nSJF Summary(WT=wait time, TT = turnaround time):\n");
  fprintf(file2,"PID\t WT\t TT\n");

  for(int t=0;t<size;t++)
  {	  
  	fprintf(file2,"%d\t%d\t%d\t\n",t,sjf_summary[t].waiting_time,sjf_summary[t].turn_around_time);
  
	total_wait_sjf+= sjf_summary[t].waiting_time;
	total_turnaround_sjf+= sjf_summary[t].turn_around_time;
  }


  float avg_waitingtime_sjf = ((float)total_wait_sjf)/size;
  float avg_turnaround_sjf = ((float)total_turnaround_sjf)/size;

  fprintf(file2,"Avg waiting time is %f and avg turnaround time is %f\n", avg_waitingtime_sjf,avg_turnaround_sjf);

  fprintf(file2,"Process sequence:\t");
  int t12 = 0;
  for(t12=0;t12<context_switches_sjf-1;t12++)
  {	  
  	fprintf(file2,"%d->\t", sjf_sequence[t12]);
  }
	fprintf(file2,"%d\n", sjf_sequence[t12]);

 fprintf(file2,"\n Context Switches: %d\n\n",context_switches_sjf);


 /*code for stcf scheduling */

 struct run_queue *stcf_run_Q = calloc(1,sizeof(*stcf_run_Q));
 if(stcf_run_Q==NULL)
   {
	   printf("Error in allocating memeory\n");
	   return 1;
   }


   for(i=0;i<size;i++)
   {
	   insert_node_stcf(&stcf_head,process[i]);     //add the processes to the priority queue

    }

   fprintf(file2,"*****STCF  Scheduling*****\n");


   //display_queue(&head);		   

   int stcf_time = 0;

 int total_wait_stcf = 0;
 int total_turnaround_stcf =0; 

   int p4=0; 
   int stcf_sched_done = 0;
   int stcf_CPU_load = 0;

   int execution_delay_stcf  = 0;


   int stcf_context_switches = 0;

   int prev2=-1;

   int stcf_CPU_load_prev = -1;
   int first_ever_load_stcf = 0;
   while(!stcf_sched_done)
   {
	   
	  
	  addnode_at_arrival_stcf(stcf_time,&stcfjobQ_head,&stcf_head);  //adding processes to the job queue as they arrive 
          if(stcf_time%timestamp==0)	
 	  {
	  fprintf(file2,"Time : %d\n", stcf_time);
	  }
	  if(stcf_CPU_load)
	  {		


		  if(execution_delay_stcf == 0)
	          {
		  	if(consecutive_iter_stcf[stcf_run_Q->id] == 0)
		 	{
			 consecutive_iter_stcf[stcf_run_Q->id] = 1;
			 }


		  	stcf_run_Q->burst_time = stcf_run_Q->burst_time -1;
			 if(stcf_time%timestamp==0){	     
			fprintf(file2,"Process %d is running in the CPU\t", stcf_run_Q->id);
			fprintf(file2,"(remaining CPU burst = %d)\n",stcf_run_Q->burst_time);
			}
			decrease_bursttime(&stcfjobQ_head,stcf_run_Q->id);

                  }

		  else
		  {
			 execution_delay_stcf = 0;
		  }


		  if(stcf_run_Q->burst_time == 0)
		  {
			 if(stcf_time%timestamp==0)	
			  fprintf(file2,"Process %d is finishing\n",stcf_run_Q->id);
			  
			  stcf_summary[stcf_run_Q->id].turn_around_time = stcf_time - get_arrivaltime_stcf(stcf_run_Q->id,&stcf_head);
	  
			  delete_node_stcf(&stcf_head,stcf_run_Q->id);    //remove node from the  Priority queue
			  
			  delete_jobQnode_stcf(&stcfjobQ_head,stcf_run_Q->id);
			  
			  stcf_CPU_load = 0;
		  }

       	  }
	  if(stcfjobQ_head!=NULL && (new_member == 1||stcf_CPU_load == 0))
	  {

		  stcf_CPU_load_prev = stcf_CPU_load;
		if(stcf_run_Q->burst_time>0 && new_member == 1)
                {
		 	if(stcf_CPU_load!=0){
		     		// fprintf(file2,"Preempting process %d\n", stcf_run_Q->id);
       
				//new_member = 0;
		       }
		}	
	       
		if(stcf_run_Q->burst_time > 0 && consecutive_iter_stcf[stcf_run_Q->id] == 1)               //if the process is being preempted, add it to the tail
		{
			
			add_preempted_node_stcf(&stcfjobQ_head,stcf_run_Q);
		       		}

                stcf_summary[stcf_run_Q->id].preempted_time = stcf_time;

		prev2 = stcf_run_Q->id;
		 load_process_stcf(stcf_run_Q,&stcfjobQ_head); //load  the short remaining burst time process to CPU

		 if(prev2!=stcf_run_Q->id||first_ever_load_stcf == 0)
	         {
	       
		 stcf_sequence[p4++] = stcf_run_Q->id;
		 stcf_context_switches++;
		 first_ever_load_stcf = 1;
		 }	
		 if(prev2!=stcf_run_Q->id)
	         {
                 
			if(stcf_CPU_load_prev == 1)
			 if(stcf_time%timestamp==0)	
		        fprintf(file2,"Preempting process %d\n", prev2);
             
			 if(stcf_time%timestamp==0){	
	 	        fprintf(file2,"Loading process %d",stcf_run_Q->id);
			fprintf(file2,"(CPU burst = %d)\n",stcf_run_Q->burst_time);
			}
                         if(consecutive_iter_stcf[stcf_run_Q->id] == 0)           //enter the waiting time details
	         	{
		  		  stcf_summary[stcf_run_Q->id].waiting_time+= stcf_time - get_arrivaltime_stcf(stcf_run_Q->id,&stcf_head);
		  		  stcf_summary[stcf_run_Q->id].proc_id = stcf_run_Q->id;
		 	}

			 else
			{

		    		stcf_summary[stcf_run_Q->id].waiting_time+= stcf_time - stcf_summary[stcf_run_Q->id].preempted_time ;
		    		stcf_summary[stcf_run_Q->id].proc_id = stcf_run_Q->id;

                	}
                }
		 stcf_CPU_load = 1;
		 new_member = 0;

	  }

	 if(stcf_time%timestamp==0)	
	 {
	 if(stcfjobQ_head!=NULL)

         //display_jobqueue_stcf(&stcfjobQ_head);
	 {

		                    struct stcfjob_Q *current_stcf;

 				  // Initialize sorted linked list
    				  struct stcfjob_Q *sorted_stcf = NULL;
 
    				// Traverse the given linked list and insert every
   			        // node to sorted
    				current_stcf = stcfjobQ_head;
    				while (current_stcf != NULL)
    				{
          				struct stcfjob_Q *next_stcf = current_stcf->next;

       				       // insert current in sorted linked list
        			      sortedInsert_stcf(&sorted_stcf, current_stcf);
					 current_stcf = next_stcf;
 
			     }
 
 
    			// Update head_ref to point to sorted linked list
    			stcfjobQ_head = sorted_stcf;


				fprintf(file2,"Ready queue:\n");
			current_stcf = stcfjobQ_head;
		while(current_stcf!=NULL && current_stcf->next!=NULL)
		{
			fprintf(file2,"%d -> ",current_stcf->pid);
			current_stcf = current_stcf->next;
		}

		if(current_stcf!=NULL)
		fprintf(file2,"%d \n", current_stcf->pid);

	}
	 else
		 fprintf(file2,"Ready Queue : empty\n");
	}
	if(isempty_stcf(&stcf_head)&&stcf_CPU_load == 0)
	 {
		 //printf("Time of end of scheduling is %d and the last process to end is %d\n", time,run_Q->id);
		 stcf_sched_done = 1;        //priority queue is empty, all processes got scheduled
	 }

	 stcf_time++;

       execution_delay_stcf = 0;

   }

        fprintf(file2,"*******************************************\nSTCF Summary(WT=wait time, TT = turnaround time):\n");
	fprintf(file2,"PID\t WT\t TT\n");
	for(int t=0;t<size;t++)
  	{	  
  		fprintf(file2,"%d\t%d\t%d\t\n",t,stcf_summary[t].waiting_time,stcf_summary[t].turn_around_time);
  
		total_wait_stcf+= stcf_summary[t].waiting_time;
		total_turnaround_stcf+= stcf_summary[t].turn_around_time;
  	}

	float avg_waitingtime_stcf = ((float)total_wait_stcf)/size;
	 float avg_turnaround_stcf = ((float)total_turnaround_stcf)/size;

 	 fprintf(file2,"Avg waiting time is %f and avg turnaround time is %f\n", avg_waitingtime_stcf,avg_turnaround_stcf);

 	 fprintf(file2,"Process sequence:\t");
	 int t15 = 0;
	  for(t15=0;t15< stcf_context_switches-1;t15++)
	  {		  
  		fprintf(file2,"%d\t->", stcf_sequence[t15]);
  	}
	  	fprintf(file2,"%d\n", stcf_sequence[t15]);


	 fprintf(file2,"\n Context Switches: %d\n",stcf_context_switches);


	 /*starting the Round robin scheduling*/

	 int total_wait_rr = 0;

	 int total_turnaround_rr =0; 

 
	 fprintf(file2,"***RR  Scheduling Summary***\n");


   int p=0;
   int context_switches_rr = 0;

   int execution_delay_rr = 0;   
   int rr_time = 0;


   struct run_queue *rr_run_Q = calloc(1,sizeof(*rr_run_Q));

   if(rr_run_Q==NULL)
   {
	   printf("Error in allocating memeory\n");
	   return 1;
   }


   for(i=0;i<size;i++)
   {
	   insert_node_rr(&rr_head,process[i]);     //add the processes to the priority queue

    }


   int rr_sched_done = 0;


   int rr_CPU_load = 0;

   int quantum = 0;


   int prev=-1;

   int new_load = 0;
   int first_ever_load = 0;

   int last_burst = -1;
   while(!rr_sched_done)
   {
	   
	  
	 addnode_at_arrival_rr(rr_time,&rrjobQ_head,&rr_head);  //adding processes to the job queue as they arrive 
          
	 add_arrived_node_rr(rr_time,&rr_node,&rr_head);
	 if(rr_time%timestamp==0)
         fprintf(file2,"Time : %d\n", rr_time);
	 if(rr_CPU_load)
	  {
		 if(execution_delay_rr == 0)
	          {
		  	rr_run_Q->burst_time = rr_run_Q->burst_time -1;
			if(rr_time%timestamp==0)
			{
				fprintf(file2,"Process %d is running in the CPU\t", rr_run_Q->id);
				fprintf(file2,"(remaining CPU burst = %d)\n",rr_run_Q->burst_time);
			}
		       	if(consecutive_iter_rr[rr_run_Q->id] == 0)
		 	{
			 consecutive_iter_rr[rr_run_Q->id] = 1;
			 }


                  }
		  else
		  {
			  execution_delay_rr = 0;
		  }
	
		 if(rr_run_Q->burst_time <= 0)
		  {

			  rr_summary[rr_run_Q->id].turn_around_time = rr_time - get_arrivaltime_rr(rr_run_Q->id,&rr_head);
		  		  
		
			  delete_node_rr(&rr_head,rr_run_Q->id);    //remove node from the  Priority queue
                          delete_jobQnode_rr(&rrjobQ_head,rr_run_Q->id); //remove the node from the job queue as well
                         // delete_robinQ(&rr_node,run_Q->id);
			  if(rr_time%timestamp==0){
			  fprintf(file2,"Process %d is finishing\n",rr_run_Q->id);
			  }
			  rr_CPU_load = 0;
		  }
	  
         }

	if(rrjobQ_head!=NULL &&  (rr_CPU_load == 0 || quantum == 2))
	  {
                   
                if(rr_run_Q->burst_time!=0 && quantum == 2)         //time quantum is 2 time units
	        {
			last_burst = rr_run_Q->burst_time;
		}
            		prev = rr_run_Q->id;
	

		 load_process_rr(&rr_node,&rr_run_Q); //load  the higher priority process to CPU
	 	
		
		 if(prev!=rr_run_Q->id||first_ever_load==0)
	         {
                        new_load = 1; 
			if(last_burst>0)
			{
					 
				if(consecutive_iter_rr[prev] == 1)               //if the process is being preempted, add it to the tail
				add_preempted_node_rr(&rr_node,prev,last_burst);

                		 rr_summary[prev].preempted_time = rr_time;


			       	if(rr_time%timestamp==0)	
				fprintf(file2,"Process %d is prempted\n",prev);
				last_burst = 0;
		 	}
			if(rr_time%timestamp==0)	
			{
			fprintf(file2,"Loading process %d\t",rr_run_Q->id);
			fprintf(file2,"(CPU burst = %d)\n",rr_run_Q->burst_time);
			}
			sequence_rr[p++] = rr_run_Q->id;
			context_switches_rr++;
		 	first_ever_load = 1;
                        if(consecutive_iter_rr[rr_run_Q->id] == 0)           //enter the waiting time details
	         	{
		  		  rr_summary[rr_run_Q->id].waiting_time+= rr_time - get_arrivaltime_rr(rr_run_Q->id,&rr_head);
		  		  rr_summary[rr_run_Q->id].proc_id = rr_run_Q->id;
			          

		 	}

			 else
			{

		    		rr_summary[rr_run_Q->id].waiting_time+= rr_time - rr_summary[rr_run_Q->id].preempted_time ;
		    		rr_summary[rr_run_Q->id].proc_id = rr_run_Q->id;

                	}
                }
		
		 execution_delay_rr = 1;

		 rr_CPU_load = 1;
		 	
		 quantum = 0;

	  }
        if(rr_time%timestamp==0)	
	{
        	if(rr_node!=NULL)
         //display_rrqueue(&rr_node,new_load);
		{
                	struct robin_Q *rr_curr_node = rr_node;


			while(rr_curr_node->next!=NULL)
			{


			fprintf(file2," %d ->\t", rr_curr_node->pid);
	        	rr_curr_node = rr_curr_node->next;
		
			}

		if(rr_curr_node!=NULL)
		fprintf(file2,"%d\n",rr_curr_node->pid);
	}
         else
		 fprintf(file2,"Ready Queue: empty\n");
	}

         if(isempty_rr(&rr_head)&&rr_CPU_load == 0)
	 {
		 //printf("Time of end of scheduling is %d and the last process to end is %d\n", time,run_Q->id);
		 rr_sched_done = 1;        //rr queue is empty, all processes got scheduled
	 }
	
	 rr_time++;
	 if(execution_delay_rr == 1)
		 execution_delay_rr = 0;

	 quantum++;


   }
 for(int t=0;t<size;t++)
  {	  
  	fprintf(file2,"%d\t%d\t%d\t\n",t,rr_summary[t].waiting_time,rr_summary[t].turn_around_time);
  
	total_wait_rr+= rr_summary[t].waiting_time;
	total_turnaround_rr+= rr_summary[t].turn_around_time;
  }

 fprintf(file2,"*******************************************\nRound Robin Summary(WT=wait time, TT = turnaround time):\n");
 fprintf(file2,"PID\t WT\t TT\n");

  float avg_waitingtime_rr = ((float)total_wait_rr)/size;
  float avg_turnaround_rr = ((float)total_turnaround_rr)/size;

  fprintf(file2,"Avg waiting time is %f and avg turnaround time is %f\n", avg_waitingtime_rr,avg_turnaround_rr);

  fprintf(file2,"Process sequence:\t");
  int t14 = 0;
  for(t14=0;t14< context_switches_rr-1;t14++)
  {	  
  	fprintf(file2,"%d->\t", sequence_rr[t14]);
  }
	fprintf(file2,"%d\n", sequence_rr[t14]);

  fprintf(file2,"Context switches = %d\n\n",context_switches_rr);

  /*starting Priority scheduling*/

  struct run_queue *priority_run_Q = calloc(1,sizeof(*priority_run_Q));
   if(priority_run_Q==NULL)
   {
	   printf("Error in allocating memeory\n");
	   return 1;
   }


   for(i=0;i<size;i++)
   {
	   insert_prioritynode(&Priority_head,process[i]);     //add the processes to the priority queue

    }
 	   

   int priority_time = 0;

   int priority_sched_done = 0;


   int priority_CPU_load = 0;

   int priority_context_switches = 0;

   int priority_execution_delay = 0;   
   fprintf(file2,"****Priority Scheduling****\n"); 
   
   while(!priority_sched_done)
   {
	   
	   addnode_at_arrival_priority(priority_time,&PriorityjobQ_head,&Priority_head);  //adding processes to the job queue as they arrive 

	   if(priority_time%timestamp==0)
	   fprintf(file2,"Time : %d\n", priority_time);

	   if(priority_sched_done==0)
	   {
		if(priority_CPU_load)
		{
		  if(priority_execution_delay == 0)
	          {
		  	priority_run_Q->burst_time = priority_run_Q->burst_time -1;
			 if(priority_time%timestamp==0){
			fprintf(file2," Process %d is running in the CPU",priority_run_Q->id);
			fprintf(file2,"(remaining burst time %d)\n",priority_run_Q->burst_time);
			}


                  }
		  else
		  {
			  priority_execution_delay = 0;
		  }
		}
	
	      	if(priority_CPU_load==1 && priority_run_Q->burst_time == 0)
		 {
			         if(priority_time%timestamp==0)
			        fprintf(file2,"Finishing process %d\n",priority_run_Q->id);
          			priority_summary[priority_run_Q->id].turn_around_time = priority_time-get_arrivaltime_priority(priority_run_Q->id,&Priority_head);     //get the turn around time of the process


			        delete_priority_node(&Priority_head,priority_run_Q->id);    //remove node from the  Priority queue
				                          
			        priority_CPU_load = 0;
                        
		  }
                  if(PriorityjobQ_head!=NULL && priority_CPU_load == 0)
	 	  {
		 	load_process_priority(priority_run_Q, &PriorityjobQ_head); //load  the higher priority process to CPU
			priority_context_switches++;

			priority_sequence[p1++] = priority_run_Q->id;

			priority_summary[priority_run_Q->id].proc_id = priority_run_Q->id;
	
			priority_summary[priority_run_Q->id].waiting_time = priority_time - get_arrivaltime_priority(priority_run_Q->id,&Priority_head);
                         if(priority_time%timestamp==0){
			fprintf(file2,"Loading process %d\t", priority_run_Q->id);
			fprintf(file2,"(CPU burst = %d)\n",priority_run_Q->burst_time);
			}
			priority_CPU_load = 1;
	
			priority_execution_delay = 1;

	  	  }



	  	}
		if(priority_time%timestamp==0){
        	if(PriorityjobQ_head!=NULL)
		{
			arrange_priority_jobqueue(&PriorityjobQ_head);
      			struct Priorityjob_Q *current_node = PriorityjobQ_head;
			while(current_node->next!=NULL)
			{
				fprintf(file2,"%d -> ",current_node->pid);
	

				current_node = current_node->next;
			}

			fprintf(file2,"%d \n", current_node->pid);

		}
	

		
		else
		fprintf(file2,"Ready Queue : empty\n");
		}
	 	if(isempty_priority(&Priority_head)&&priority_CPU_load == 0)
	 	{
				 	priority_sched_done = 1;        //priority queue is empty, all processes got scheduled
	 	}
	
	 priority_time++;

	 if(priority_execution_delay == 1)
		 priority_execution_delay = 0;


   }
 int total_wait_priority = 0;
 int total_turnaround_priority =0; 

 fprintf(file2,"*******************************************\nPriority Summary(WT=wait time, TT = turnaround time):\n");
 fprintf(file2,"PID\t WT\t TT\n");



  for(int t=0;t<size;t++)
  {	  
  	fprintf(file2,"%d\t%d\t%d\t\n",t,priority_summary[t].waiting_time,priority_summary[t].turn_around_time);
  
	total_wait_priority+= priority_summary[t].waiting_time;
	total_turnaround_priority+= priority_summary[t].turn_around_time;
  }

  float avg_waitingtime_priority = ((float)total_wait_priority)/size;
  float avg_turnaround_priority = ((float)total_turnaround_priority)/size;

  fprintf(file2,"Avg waiting time is %f and avg turnaround time is %f\n", avg_waitingtime_priority,avg_turnaround_priority);

  fprintf(file2,"Process sequence:\t");
  int t11=0;
  for( t11=0;t11<p1-1;t11++)
  {	  
  	fprintf(file2,"%d->\t", priority_sequence[t11]);
  }
	fprintf(file2,"%d\n", priority_sequence[t11]);

 fprintf(file2,"\n Context Switches: %d\n",priority_context_switches);

 /*code for overall summary*/

      fprintf(file2,"\n\n******Overall Summary*****\n");

      struct schedule_summary  *summary_head = NULL;
      struct schedule_summary  *summary_temp1 = calloc(1,sizeof(*summary_temp1));
      if(summary_temp1==NULL)
      {
	   printf("Error in allocating memeory\n");
	   return 1;
      }

      struct schedule_summary  *summary_temp2 = calloc(1,sizeof(*summary_temp2));
      if(summary_temp2==NULL)
      {
	   printf("Error in allocating memeory\n");
	   return 1;
      }

      struct schedule_summary  *summary_temp3 = calloc(1,sizeof(*summary_temp3));
      if(summary_temp3==NULL)
      {
	   printf("Error in allocating memeory\n");
	   return 1;
      }

     struct schedule_summary  *summary_temp4 = calloc(1,sizeof(*summary_temp4));
      if(summary_temp4==NULL)
      {
	   printf("Error in allocating memeory\n");
	   return 1;
      }

     struct schedule_summary  *summary_temp5 = calloc(1,sizeof(*summary_temp5));
      if(summary_temp5==NULL)
      {
	   printf("Error in allocating memeory\n");
	   return 1;
      }
     
     
      strcpy(summary_temp1->type,"STCF");
      summary_temp1->wait_time =  avg_waitingtime_stcf;
      summary_temp1->turn_around_time = avg_turnaround_stcf;
      summary_temp1->context_switch_count = stcf_context_switches;

      summary_head = summary_temp1;
     
      strcpy(summary_temp2->type,"Round_Robin");
      summary_temp2->wait_time =  avg_waitingtime_rr;
      summary_temp2->turn_around_time = avg_turnaround_rr;
      summary_temp2->context_switch_count = context_switches_rr;

      summary_head->next = summary_temp2;
     
      strcpy(summary_temp3->type,"FCFS");
      summary_temp3->wait_time =  avg_waitingtime_fcfs;
      summary_temp3->turn_around_time = avg_turnaround_fcfs;
      summary_temp3->context_switch_count = fifo_context_switches;

      summary_head->next->next = summary_temp3;
     
      strcpy(summary_temp4->type,"SJF");
      summary_temp4->wait_time =  avg_waitingtime_sjf;
      summary_temp4->turn_around_time = avg_turnaround_sjf;
      summary_temp4->context_switch_count = context_switches_sjf;

      summary_head->next->next->next = summary_temp4;
     
      strcpy(summary_temp5->type,"Priority");
      summary_temp5->wait_time =  avg_waitingtime_priority;
      summary_temp5->turn_around_time = avg_turnaround_priority;
      summary_temp5->context_switch_count = priority_context_switches;


       summary_head->next->next->next->next = summary_temp5;
       summary_head->next->next->next->next->next = NULL;

      struct schedule_summary* current_summ = summary_head;
      if(current_summ==NULL)
      {
	      printf("Summary node head is NULL\n");
              return 1; 
      }

     
      // Initialize sorted linked list
      struct schedule_summary *sorted_summ = NULL;
 
      // Traverse the given linked list and insert every
      // node to sorted
      while (current_summ != NULL)
     {
          	struct schedule_summary *next_summ = current_summ->next;

       	        // insert current in sorted linked list
        	sortedInsert_summ_wait(&sorted_summ,current_summ);
		current_summ = next_summ;
 
     }
 
 
     // Update head_ref to point to sorted linked list
     summary_head = sorted_summ;

     fprintf(file2,"\nWait time comparision:\n");
     current_summ = summary_head;
     int s1 = 0;
     while(current_summ!=NULL)
     {
			fprintf(file2,"%d.%s--------->%f\n",s1,current_summ->type,current_summ->wait_time);
			current_summ = current_summ->next;
			s1++;
      }

      //turnaround time comparision

      current_summ = summary_head;
      if(current_summ==NULL)
      {
	      printf("Summary node head is NULL\n");
              return 1; 
      }

    
      // Initialize sorted linked list
      sorted_summ = NULL;
 
      // Traverse the given linked list and insert every
      // node to sorted
      while (current_summ != NULL)
     {
          	struct schedule_summary *next_summ = current_summ->next;

       	        // insert current in sorted linked list
        	sortedInsert_summ_turnaround(&sorted_summ,current_summ);
		current_summ = next_summ;
 
     }
 
 
     // Update head_ref to point to sorted linked list
     summary_head = sorted_summ;


     fprintf(file2,"\n\nTurnAround  time comparision:\n");
     current_summ = summary_head;
     s1 = 0;
     while(current_summ!=NULL)
     {
			fprintf(file2,"%d.%s-------->%f\n",s1,current_summ->type,current_summ->turn_around_time);
			current_summ = current_summ->next;
			s1++;
      }
     
     //Context Switches comparision

      current_summ = summary_head;
      if(current_summ==NULL)
      {
	      printf("Summary node head is NULL\n");
              return 1; 
      }

    
      // Initialize sorted linked list
      sorted_summ = NULL;
 
      // Traverse the given linked list and insert every
      // node to sorted
      while (current_summ != NULL)
     {
          	struct schedule_summary *next_summ = current_summ->next;

       	        // insert current in sorted linked list
        	sortedInsert_summ_contextswitch(&sorted_summ,current_summ);
		current_summ = next_summ;
 
     }
 
 
     // Update head_ref to point to sorted linked list
     summary_head = sorted_summ;


     fprintf(file2,"\n\nContext Switch comparision:\n");
     current_summ = summary_head;
     s1 = 0;
     while(current_summ!=NULL)
     {
			fprintf(file2,"%d.%s------->%d\n",s1,current_summ->type,current_summ->context_switch_count);
			current_summ = current_summ->next;
			s1++;
      }
   
     fclose(file2);

     return 0;
}
