/* common to all types of scheduling*/

struct Process_info{       //structure for getting process info

        int id;
	int burst;
	int priority;
	int arrival;
};
struct proc_summary       //summary of the processes       

{
	int proc_id;
	int waiting_time;
	int turn_around_time;
	//int preempted_time;
};
struct run_queue
{
	int id;
	int burst_time;
};
extern struct Process_info process[10000];
extern int size;


/*structure and function prototypes for priority scheduling*/
struct  PriorityQ_node
{
	int pid;
	
	int burst_time;
	int priority;
	int arrival;
	struct PriorityQ_node *next;
};

struct Priorityjob_Q 
{
	int pid;
	
	int burst_time;
	int priority;
	int arrival;
	struct Priorityjob_Q *next;
};
extern void sortedInsert_arrival(struct Priorityjob_Q** head_ref, struct Priorityjob_Q* new_node);

extern void load_process_priority(struct run_queue *run_Q, struct Priorityjob_Q **PriorityjobQ_head);
extern int isempty_priority(struct PriorityQ_node **Priority_head);
extern void delete_priority_node(struct PriorityQ_node **Priority_head, int id);
extern void addnode_at_arrival_priority(int priority_time,struct Priorityjob_Q **PriorityjobQ_head, struct PriorityQ_node **Priority_head);
extern void arrange_priority_jobqueue(struct Priorityjob_Q **PriorityjobQ_head);
extern void display_priority_queue(struct PriorityQ_node **Priority_head);
extern void insert_prioritynode(struct PriorityQ_node **Priority_head, struct Process_info proc);
extern void getProcessinfo(char *str);
extern int get_arrivaltime_priority(int id, struct PriorityQ_node** Priority_head);
extern void sortedInsert_priority(struct Priorityjob_Q** head_ref, struct Priorityjob_Q* new_node);

/*structure and function prototypes for fcfs scheduling*/
struct  FifoQ_node
{
	int pid;
	int burst_time;
	int priority;
	int arrival;
	struct FifoQ_node *next;
};

struct fifojob_Q 
{
	int pid;
	int burst_time;
	int priority;
	int arrival;
	struct fifojob_Q *next;
};

extern void insert_node_fifo(struct FifoQ_node **fifo_head, struct Process_info proc);
extern void display_queue_fifo(struct FifoQ_node **fifo_head);
extern void display_jobqueue_fifo(struct fifojob_Q **fifojobQ_head);
extern void addnode_at_arrival_fifo(int time,struct fifojob_Q **fifojobQ_head, struct FifoQ_node **fifo_head);
extern void delete_node_fifo(struct FifoQ_node **fifo_head, int id);
extern int isempty_fifo(struct FifoQ_node **head);
extern void load_process_fifo(struct run_queue *fifo_run_Q, struct fifojob_Q **fifojobQ_head);
//extern void getProcessinfo();
extern void delete_jobQnode_fifo(struct fifojob_Q **fifojobQ_head, int id);
extern int get_arrivaltime_fifo(int id,struct FifoQ_node **fifo_head);

/*structures and functions related to sjf scheduling*/
struct  sjfQ_node
{
	int pid;
	
	int burst_time;
	int priority;
	int arrival;
	struct sjfQ_node *next;
};

struct sjfjob_Q 
{
	int pid;
	
	int burst_time;
	int priority;

	struct sjfjob_Q *next;
};




extern void load_process_sjf(struct run_queue *sjf_run_Q, struct sjfjob_Q **sjfjobQ_head);
extern int isempty_sjf(struct sjfQ_node **sjf_head);
extern void delete_node_sjf(struct sjfQ_node **sjf_head, int id);
extern void addnode_at_arrival_sjf(int time,struct sjfjob_Q **sjfjobQ_head, struct sjfQ_node **sjf_head);
extern void arrange_jobqueue_sjf(struct sjfjob_Q **sjfjobQ_head);
extern void display_queue_sjf(struct sjfQ_node **sjf_head);
extern void insert_node_sjf(struct sjfQ_node **sjf_head, struct Process_info proc);
//extern void getProcessinfo();
extern int get_arrivaltime_sjf(int id, struct sjfQ_node **sjf_head);

/*structures and functions related to round robin scheduling*/
struct  RRQ_node
{
	int pid;
	int burst_time;
	int priority;
	int arrival;
	struct RRQ_node *next;
};

struct rrjob_Q 
{
	int pid;
	
	int burst_time;
	int priority;

	struct rrjob_Q *next;
};

struct robin_Q
{
	int pid;
	int burst_time;
	int priority;
	int arrival;
	struct robin_Q *next;
};
struct proc_rrsummary       //summary of the processes       
{
	int proc_id;
	int preempted_time;
	int waiting_time;
	int turn_around_time;
};




extern int isempty_rr(struct RRQ_node **rr_head);
extern void  delete_jobQnode_rr(struct rrjob_Q **rrjobQ_head,int id);
extern void delete_node_rr(struct RRQ_node **rr_head, int id);
extern void addnode_at_arrival_rr(int time,struct rrjob_Q **rrjobQ_head,struct RRQ_node **rr_head);
extern void insert_node_rr(struct RRQ_node **rr_head, struct Process_info proc);
extern void getProcessinfo();
extern int get_arrivaltime_rr(int id, struct RRQ_node **rr_head);
extern void display_rrqueue(struct robin_Q **rr_node,int new_load);
extern void load_process_rr(struct robin_Q **rr_node,struct run_queue **rr_run_Q);  
extern void add_arrived_node_rr(int time,struct robin_Q **rr_node,struct RRQ_node **rr_head);
void add_preempted_node_rr(struct robin_Q **rr_node,int id, int burst);

/*structures and function prototypes required for stcf scheduling*/
struct  stcfQ_node
{
	int pid;
	
	int burst_time;
	int priority;
	int arrival;
	struct stcfQ_node *next;
};

struct stcfjob_Q 
{
	int pid;
	
	int burst_time;
	int priority;

	struct stcfjob_Q *next;
};

struct proc_stcfsummary       //summary of the processes       

{
	int proc_id;
	int preempted_time;
	int waiting_time;
	int turn_around_time;
};




extern void load_process_stcf(struct run_queue *stcf_run_Q, struct stcfjob_Q **stcfjobQ_head);
extern int isempty_stcf(struct stcfQ_node **stcfhead);
extern void delete_node_stcf(struct stcfQ_node **stcf_head, int id);
extern void addnode_at_arrival_stcf(int time,struct stcfjob_Q **stcfjobQ_head, struct stcfQ_node **stcf_head);
extern void display_jobqueue_stcf(struct stcfjob_Q **stcfjobQ_head);
extern void display_queue_stcf(struct stcfQ_node **stcf_head);
extern void insert_node_stcf(struct stcfQ_node **stcf_head, struct Process_info proc);
extern void getProcessinfo();
extern void  delete_jobQnode_stcf(struct stcfjob_Q **stcfjobQ_head,int id);
extern void  decrease_bursttime(struct stcfjob_Q **stcfjobQ_head,int id);

extern  int get_arrivaltime_stcf(int id,struct  stcfQ_node **stcf_head);
extern void add_preempted_node_stcf(struct stcfjob_Q **stcf_jobQ_head,struct run_queue *stcf_run_Q);
//extern void add_arrived_node(int time,struct robin_Q **rr_node,struct RRQ_node *head);
extern int isMinBurst(int burst_time,struct stcfjob_Q* stcfjobQ_head);
extern void sortedInsert_stcf(struct stcfjob_Q** head_ref, struct stcfjob_Q* new_node);

/* structures and functions to compute the overall summary*/

struct schedule_summary
{
	char type[100];
	float wait_time;
	float turn_around_time;
	int  context_switch_count;
	struct schedule_summary *next;
};

void sortedInsert_summ_wait(struct schedule_summary** head_ref, struct schedule_summary* new_node);
void sortedInsert_summ_turnaround(struct schedule_summary** head_ref, struct schedule_summary* new_node);
void sortedInsert_summ_contextswitch(struct schedule_summary** head_ref, struct schedule_summary* new_node);


