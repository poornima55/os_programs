#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
#include"sched_sim.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

int k = 0;

extern struct Process_info process[10000]; //can hold 10000 processes
extern int size;
extern struct  PriorityQ_node *Priority_head; //priority queue head and tail
extern struct PriorityQ_node *Priority_last;
extern struct Priorityjob_Q *PriorityjobQ_head;  //job queue  head and tail
extern struct Priorityjob_Q *PriorityjobQ_last;

extern struct FifoQ_node *fifo_head; //priority queue head and tail
extern struct FifoQ_node *fifo_last;
extern struct fifojob_Q *fifojobQ_head;  //job queue  head and tail
extern struct fifojob_Q *fifojobQ_last;

extern struct sjfQ_node *sjf_head; //priority queue head and tail
extern struct sjfQ_node *sjf_last;
extern struct sjfjob_Q *sjfjobQ_head;  //job queue  head and tail
extern struct sjfjob_Q *sjfjobQ_last;

extern struct  RRQ_node *rr_head; //priority queue head and tail
extern struct RRQ_node *rr_last;
extern struct rrjob_Q *rrjobQ_head;  //job queue  head and tail
extern struct proc_rrsummary rr_summary[10000]; 
extern struct robin_Q *rr_node;



extern struct stcfQ_node *stcf_head; //priority queue head and tail
extern struct stcfQ_node *stcf_last;
extern struct stcfjob_Q *stcfjobQ_head;  //job queue  head and tail
extern struct stcfjob_Q *stcfjobQ_last;
extern int size;
extern int new_member;

extern struct proc_stcfsummary stcf_summary[10000];

extern void getProcessinfo(char *str)
{
  

    char filename[100] = {'\0',};
    FILE  *fd = NULL;
    strncpy(filename,str,100);
    
   
      fd = fopen (filename,"r");
    if (fd == NULL) {
            printf ("failed to open the input file\n");
            return ;
    }

 
    char c;
    int count=1;
    // Extract characters from file and store in character c
    for (c = getc(fd); c != EOF; c = getc(fd))
    { 
        if (c == '\n') // Increment count if this character is newline
            count = count + 1;
    }

  
   fseek(fd,0,SEEK_SET);

 
     while(k<count)
     {	     
     		process[k].id = k;
		fscanf(fd,"%d %d %d",&process[k].burst,&process[k].priority,&process[k].arrival);
		//printf("%d %d %d",process[k].burst,process[k].priority,process[k].arrival);

		k++;
     }

      fclose(fd);
      size = count;
    return;

}


void insert_prioritynode(struct PriorityQ_node **Priority_head, struct Process_info proc)
{
	struct  PriorityQ_node *temp = (struct PriorityQ_node*)calloc(1,sizeof(struct PriorityQ_node));

	temp->pid = proc.id;
	temp->burst_time = proc.burst;
	temp->priority = proc.priority;
	temp->arrival = proc.arrival;
       
	if(*Priority_head==NULL)
	{
		*Priority_head = temp;
		Priority_last = temp;
	
	}
	else
	{
		
	

		Priority_last->next = temp;
		Priority_last = temp;
	}
}


void display_queue_priority(struct PriorityQ_node **head)
{
	struct PriorityQ_node *current = *head;
	while(current!=NULL)
	{
		printf("Process id is %d and  Burst time is %d\n",current->pid,current->burst_time);
		current = current->next;
	}
}

/* function to insert a new_node in a list. Note that this
  function expects a pointer to head_ref as this can modify the
  head of the input linked list (similar to push())*/
void sortedInsert_priority(struct Priorityjob_Q** head_ref, struct Priorityjob_Q* new_node)
{
    struct Priorityjob_Q* current;
    /* Special case for the head end */
    if (*head_ref == NULL || (*head_ref)->priority > new_node->priority)
    {
        new_node->next = *head_ref;
        *head_ref = new_node;
    }
    else
    {
        /* Locate the node before the point of insertion */
        current = *head_ref;
        while (current->next!=NULL &&
               current->next->priority < new_node->priority)
        {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
}

void arrange_priority_jobqueue(struct Priorityjob_Q **Priority_head_ref)
{
        
    struct Priorityjob_Q *current;

   // Initialize sorted linked list
    struct Priorityjob_Q *sorted = NULL;
 
    // Traverse the given linked list and insert every
    // node to sorted
    current = *Priority_head_ref;
    while (current != NULL)
    {
          struct Priorityjob_Q *next = current->next;

        // insert current in sorted linked list
         sortedInsert_priority(&sorted, current);
	 current = next;
 
     }
 
    // Update head_ref to point to sorted linked list
    *Priority_head_ref = sorted;

}
void addnode_at_arrival_priority(int time,struct Priorityjob_Q **PriorityjobQ_head, struct PriorityQ_node **Priority_head)
{

  //struct job_Q *temp_node = (struct job_Q*) malloc ( sizeof (struct job_Q));
	struct Priorityjob_Q *temp_node = NULL;
	struct PriorityQ_node *current = *Priority_head;
 

	while(current!= NULL)
	{
		//printf("the node in the priority queue is %d with the burst time\n", current->pid,current->burst_time);
		if(current->arrival == time)
		{
		  temp_node = calloc (1, sizeof (*temp_node));
				      
		           	temp_node->pid = current-> pid;
	
				temp_node->burst_time = current->burst_time;
				temp_node->priority = current->priority;
				temp_node->arrival = current->arrival;
		                
				if(*PriorityjobQ_head==NULL)
				{
	                              	
					*PriorityjobQ_head = temp_node;
					 PriorityjobQ_last = temp_node;

					 //printf("The head of the job queue is %d with the burst time %d\n",(*jobQ_head)->pid,(*jobQ_head)->burst_time);
	
				}
				else
				{
					struct Priorityjob_Q *last = *PriorityjobQ_head;
					while(last->next!=NULL)
					{
						last = last->next;
					}
			
	            			//printf("node added to the tail of job queue is %d\n",temp_node->pid);
					(last)->next = temp_node;
					(last) = temp_node;

		
				}



			
                     }

		
			current = current->next;
		}
	

}
void delete_priority_node(struct PriorityQ_node **Priority_head, int id)
{

	struct PriorityQ_node  *current_node = *Priority_head;
        //struct job_Q *prev = curr_node;
	struct PriorityQ_node *previous1 = NULL;
	struct PriorityQ_node *temp1 = NULL; 
	       
	while (current_node != NULL) {


    		   if (id == current_node->pid)
	           {
			
			   temp1 = current_node;
			   if (current_node == *Priority_head)
			   
				   *Priority_head = current_node->next;
			   

			   if (previous1)
				   previous1->next = temp1->next;

			   current_node = current_node->next;
			   free (temp1);
		   }

		   else
		   {
		   	previous1 = current_node;
			current_node = current_node->next;
		   }


	}

}

int isempty_priority(struct PriorityQ_node **Priority_head)
{
	if(*Priority_head==NULL)
		return 1;
	else
		return 0;
}
void sortedInsert_arrival(struct Priorityjob_Q** head_ref, struct Priorityjob_Q* new_node)
{
    struct Priorityjob_Q* current;
    /* Special case for the head end */
    if (*head_ref == NULL || (*head_ref)->arrival > new_node->arrival)
    {
        new_node->next = *head_ref;
        *head_ref = new_node;
    }
    else
    {
        /* Locate the node before the point of insertion */
        current = *head_ref;
        while (current->next!=NULL &&
               current->next->arrival < new_node->arrival)
        {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
}


void load_process_priority(struct run_queue *priority_run_Q, struct Priorityjob_Q **PriorityjobQ_head)  
{

	struct Priorityjob_Q *curr_node = *PriorityjobQ_head;

	int min =  10000;
	struct Priorityjob_Q *tmp = NULL;

	 // Check loop while node not equal to NULL
   	 while (curr_node != NULL) {

	//	   printf("The current node pid is %d and the priority is %d\n",curr_node->pid,curr_node->priority);
    		   if (min >= curr_node->priority)
            	   min =  curr_node->priority;
	         
	//	   printf("The minimum priority is %d \n",min);
		  
        	   curr_node = curr_node->next;
          }


  struct Priorityjob_Q *current_pri;

   // Initialize sorted linked list
    struct Priorityjob_Q *sorted = NULL;
 
    // Traverse the given linked list and insert every
    // node to sorted
    current_pri = *PriorityjobQ_head;
    while (current_pri != NULL)
    {
          struct Priorityjob_Q *next = current_pri->next;

        // insert current in sorted linked list
         sortedInsert_arrival(&sorted, current_pri);
	 current_pri = next;
 
     }
 
    // Update head_ref to point to sorted linked list

    *PriorityjobQ_head = sorted;



	 //load the process with min priority number to CPU and delete it from the job queue

	curr_node = *PriorityjobQ_head;
        //struct job_Q *prev = curr_node;
	struct Priorityjob_Q *prev = NULL;

	int rem_node;
	 while (curr_node != NULL) {


    		   if(min == curr_node->priority)
	           {

			  // printf("the value of min is %d and the current node's priority is %d\n",min,curr_node->priority);
			   rem_node = curr_node->pid;
			   break;

	           }

		   curr_node = curr_node->next;
	
		 }

	 curr_node = *PriorityjobQ_head;

	 while(curr_node!=NULL)
	{

		         if(rem_node == curr_node->pid)
		         {
			   
                           priority_run_Q->id = curr_node->pid;
			   priority_run_Q->burst_time = curr_node->burst_time;

			   tmp = curr_node;
			   if (curr_node == *PriorityjobQ_head)
			   
				   *PriorityjobQ_head = curr_node->next;
			   

			   if (prev)
				   prev->next = tmp->next;

			   curr_node = curr_node->next;
			   free (tmp);
		   }

		   else
		   {
		   	prev = curr_node;
			curr_node = curr_node->next;
		   }


	}

}

/*to get the arrival time*/
int get_arrivaltime_priority(int id,struct  PriorityQ_node **Priority_head)
{

	struct  PriorityQ_node *current = *Priority_head;

	while(current!=NULL)
	{
		if(current->pid == id)
		{
			return current->arrival;
		}

		else
		{
			current = current->next;
		}
	}
}

void insert_node_fifo(struct FifoQ_node **fifo_head, struct Process_info proc)
{
	struct  FifoQ_node *temp = (struct FifoQ_node*)calloc(1,sizeof(struct FifoQ_node));

	temp->pid = proc.id;
	temp->burst_time = proc.burst;
	temp->priority = proc.priority;
	temp->arrival = proc.arrival;
       
	if(*fifo_head==NULL)
	{
		*fifo_head = temp;
		fifo_last = temp;
	
	}
	else
	{
		
	

		fifo_last->next = temp;
		fifo_last = temp;
	}
}

void display_queue_fifo(struct FifoQ_node **fifo_head)
{
	struct FifoQ_node *current = *fifo_head;
	while(current!=NULL)
	{
		printf("Process id is %d and  Burst time is %d\n",current->pid,current->burst_time);
		current = current->next;
	}
}
void display_jobqueue_fifo(struct fifojob_Q **fifojobQ_head)
{

	struct fifojob_Q  *current = *fifojobQ_head;
	printf("Ready Queue: ");
	while(current!=NULL && current->next!=NULL)
	{
		printf("%d-> ",current->pid);
		current = current->next;
	}
	if(current!=NULL)
        printf("%d \n",current->pid);


}
void addnode_at_arrival_fifo(int time,struct fifojob_Q **fifojobQ_head, struct FifoQ_node **fifo_head)
{

  //struct job_Q *temp_node = (struct job_Q*) malloc ( sizeof (struct job_Q));
	struct fifojob_Q *temp_node = NULL;
	struct FifoQ_node *current = *fifo_head;
        
	struct fifojob_Q *last = NULL;

	while(current!= NULL)
	{
		//printf("the node in the priority queue is %d with the burst time\n", current->pid,current->burst_time);
		if(current->arrival == time)
		{
		 	       
		         	temp_node = calloc (1, sizeof (*temp_node));
				      
		           	temp_node->pid = current-> pid;
	
				temp_node->burst_time = current->burst_time;
				temp_node->priority = current->priority;
				temp_node->arrival = current->arrival;
		                
				if(*fifojobQ_head==NULL)
				{
	                              	
					*fifojobQ_head = temp_node;
					fifojobQ_last = temp_node;
					 //printf("The head of the job queue is %d with the burst time %d\n",(*jobQ_head)->pid,(*jobQ_head)->burst_time);
	
				}
				else
				{

					
						
					fifojobQ_last->next = temp_node;
					fifojobQ_last  = temp_node;
				}

			
                     }

		
			current = current->next;
		}

}
void delete_node_fifo(struct FifoQ_node **fifo_head, int id)
{

	struct FifoQ_node  *current_node = *fifo_head;
        //struct job_Q *prev = curr_node;
	struct FifoQ_node *previous1 = NULL;
	struct FifoQ_node *temp1 = NULL; 
	       
	while (current_node != NULL) {


    		   if (id == current_node->pid)
	           {
			
			  // printf("The deleted node is %d\n", current_node->pid);
			   temp1 = current_node;
			   if (current_node == *fifo_head)
			   
				   *fifo_head = current_node->next;
			   

			   if (previous1)
				   previous1->next = temp1->next;

			   current_node = current_node->next;
			   free (temp1);
		   }

		   else
		   {
		   	previous1 = current_node;
			current_node = current_node->next;
		   }


	}

}
void delete_jobQnode_fifo(struct fifojob_Q **fifojobQ_head, int id)
{

	struct fifojob_Q  *current_node = *fifojobQ_head;
        //struct job_Q *prev = curr_node;
	struct fifojob_Q *previous1 = NULL;
	struct fifojob_Q *temp1 = NULL; 
	       
	while (current_node != NULL) {


    		   if (id == current_node->pid)
	           {
			
			  // printf("The deleted node is %d\n", current_node->pid);
			   temp1 = current_node;
			   if (current_node == *fifojobQ_head)
			   
				   *fifojobQ_head = current_node->next;
			   

			   if (previous1)
				   previous1->next = temp1->next;

			   current_node = current_node->next;
			   free (temp1);
		   }

		   else
		   {
		   	previous1 = current_node;
			current_node = current_node->next;
		   }


	}

}


int isempty_fifo(struct FifoQ_node **fifo_head)
{
	if(*fifo_head==NULL)
		return 1;
	else
		return 0;
}

void load_process_fifo(struct run_queue *fifo_run_Q, struct fifojob_Q **fifojobQ_head)  
{

	struct fifojob_Q *curr_node = *fifojobQ_head;



	 //load the process with min priority number to CPU and delete it from the job queue

	curr_node = *fifojobQ_head;
        //struct job_Q *prev = curr_node;
	struct fifojob_Q *prev = NULL;

	if(curr_node!=NULL)
	{

                 fifo_run_Q->id = curr_node->pid;
	         fifo_run_Q->burst_time = curr_node->burst_time;	   
	         *fifojobQ_head = curr_node->next;		

	}

}





/*to get the arrival time*/
int get_arrivaltime_fifo(int id,struct  FifoQ_node **fifo_head)
{

	struct  FifoQ_node *current = *fifo_head;

	while(current!=NULL)
	{
		if(current->pid == id)
		{
			return current->arrival;
		}

		else
		{
			current = current->next;
		}
	}
}

/*functions related to sjf scheduling*/
void insert_node_sjf(struct sjfQ_node **sjf_head, struct Process_info proc)
{
	struct  sjfQ_node *temp = (struct sjfQ_node*)calloc(1,sizeof(struct sjfQ_node));

	temp->pid = proc.id;
	temp->burst_time = proc.burst;
	temp->priority = proc.priority;
	temp->arrival = proc.arrival;
       
	if(*sjf_head==NULL)
	{
		*sjf_head = temp;
		sjf_last = temp;
	
	}
	else
	{
		
	

		sjf_last->next = temp;
		sjf_last = temp;
	}
}


void display_queue_sjf(struct sjfQ_node **sjf_head)
{
	struct sjfQ_node *current = *sjf_head;
	while(current!=NULL)
	{
		printf("Process id is %d and  Burst time is %d\n",current->pid,current->burst_time);
		current = current->next;
	}
}

void sortedInsert_sjf(struct sjfjob_Q** head_ref, struct sjfjob_Q* new_node)
{
    struct sjfjob_Q* current;
    /* Special case for the head end */
    if (*head_ref == NULL || (*head_ref)->burst_time > new_node->burst_time)
    {
        new_node->next = *head_ref;
        *head_ref = new_node;
    }
    else
    {
        /* Locate the node before the point of insertion */
        current = *head_ref;
        while (current->next!=NULL &&
               current->next->burst_time < new_node->burst_time)
        {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
}





void arrange_jobqueue_sjf(struct sjfjob_Q **head_ref)
{

  
    struct sjfjob_Q *current;

   // Initialize sorted linked list
    struct sjfjob_Q *sorted = NULL;
 
    // Traverse the given linked list and insert every
    // node to sorted
    current = *head_ref;
    while (current != NULL)
    {
          struct sjfjob_Q *next = current->next;

        // insert current in sorted linked list
         sortedInsert_sjf(&sorted, current);
	 current = next;
 
     }
 
    // Update head_ref to point to sorted linked list

    *head_ref = sorted;



}


void addnode_at_arrival_sjf(int time,struct sjfjob_Q **sjfjobQ_head,struct sjfQ_node **sjf_head)
{

  //struct job_Q *temp_node = (struct job_Q*) malloc ( sizeof (struct job_Q));
	struct sjfjob_Q *temp_node = NULL;
	struct sjfQ_node *current = *sjf_head;
       
	while(current!= NULL)
	{
		if(current->arrival == time)
		{


		                temp_node = calloc (1, sizeof (*temp_node));
				      
		           	temp_node->pid = current-> pid;
				temp_node->burst_time = current->burst_time;
				temp_node->priority = current->priority;
				
		                
				if(*sjfjobQ_head==NULL)
				{
	                              	
					*sjfjobQ_head = temp_node;
					
					//last = *jobQ_last;
					
				}
					else
				{


		
					struct sjfjob_Q *last = *sjfjobQ_head;
					while(last->next!=NULL)
					{
						last = last->next;
					}
			
					(last)->next = temp_node;
					(last) = temp_node;
				}


			
                     }

		
			current = current->next;
		}


}



void delete_node_sjf(struct sjfQ_node **sjf_head, int id)
{

	struct sjfQ_node  *current_node = *sjf_head;
        //struct job_Q *prev = curr_node;
	struct sjfQ_node *previous1 = NULL;
	struct sjfQ_node *temp1 = NULL; 
	       
	while (current_node != NULL) {


    		   if (id == current_node->pid)
	           {
			
			   temp1 = current_node;
			   if (current_node == *sjf_head)
			   
				   *sjf_head = current_node->next;
			   

			   if (previous1)
				   previous1->next = temp1->next;

			   current_node = current_node->next;
			   free (temp1);
		   }

		   else
		   {
		   	previous1 = current_node;
			current_node = current_node->next;
		   }


	}

}

int isempty_sjf(struct sjfQ_node **sjf_head)
{
	if(*sjf_head==NULL)
		return 1;
	else
		return 0;
}
void load_process_sjf(struct run_queue *sjf_run_Q, struct sjfjob_Q **sjfjobQ_head)  
{

	struct sjfjob_Q *curr_node = *sjfjobQ_head;

	int min =  10000;
	struct sjfjob_Q *tmp = NULL;

	 // Check loop while node not equal to NULL
   	 while (curr_node != NULL) {

    		   if (min > curr_node->burst_time)
            	   min =  curr_node->burst_time;
	         
	//	   printf("The minimum priority is %d \n",min);
		  
        	   curr_node = curr_node->next;
          }
	

	 //load the process with min priority number to CPU and delete it from the job queue

	curr_node = *sjfjobQ_head;
        //struct job_Q *prev = curr_node;
	struct sjfjob_Q *prev = NULL;

	int rem_node;
	 while (curr_node != NULL) {


    		   if(min == curr_node->burst_time)
	           {

			   rem_node = curr_node->pid;
			   break;

	           }

		   curr_node = curr_node->next;
	
		 }

	 curr_node = *sjfjobQ_head;
	 while(curr_node!=NULL)
	{

		         if(rem_node == curr_node->pid)
		         {
			 
                           sjf_run_Q->id = curr_node->pid;
			   sjf_run_Q->burst_time = curr_node->burst_time;

			   tmp = curr_node;
			   if (curr_node == *sjfjobQ_head)
			   
				   *sjfjobQ_head = curr_node->next;
			   

			   if (prev)
				   prev->next = tmp->next;

			   curr_node = curr_node->next;
			   free (tmp);
		   }

		   else
		   {
		   	prev = curr_node;
			curr_node = curr_node->next;
		   }


	}

}



/*to get the arrival time*/
int get_arrivaltime_sjf(int id,struct  sjfQ_node **sjf_head)
{

	struct  sjfQ_node *current = *sjf_head;

	while(current!=NULL)
	{
		if(current->pid == id)
		{
			return current->arrival;
		}

		else
		{
			current = current->next;
		}
	}
}


void insert_node_rr(struct RRQ_node **rr_head, struct Process_info proc)
{
	struct  RRQ_node *temp = (struct RRQ_node*)calloc(1,sizeof(struct RRQ_node));

	temp->pid = proc.id;
	temp->burst_time = proc.burst;
	temp->priority = proc.priority;
	temp->arrival = proc.arrival;
       
	if(*rr_head==NULL)
	{
		*rr_head = temp;
		rr_last = temp;
	
	}
	else
	{
		
	

		rr_last->next = temp;
		rr_last = temp;
	}
}

void addnode_at_arrival_rr(int time,struct rrjob_Q **rrjobQ_head,struct RRQ_node **rr_head)
{

  //struct job_Q *temp_node = (struct job_Q*) malloc ( sizeof (struct job_Q));
	struct rrjob_Q *temp_node = NULL;
	struct RRQ_node *current = *rr_head;
       
	while(current!= NULL)
	{
		if(current->arrival == time)
		{


		                temp_node = calloc (1, sizeof (*temp_node));
				      
		           	temp_node->pid = current-> pid;
				temp_node->burst_time = current->burst_time;
				temp_node->priority = current->priority;
				
		                
				if(*rrjobQ_head==NULL)
				{
	                              	
					*rrjobQ_head = temp_node;
					
					//last = *jobQ_last;
					
				}

                   		  else
		     		{


					struct rrjob_Q *last = *rrjobQ_head;
					while(last->next!=NULL)
					{
						last = last->next;
					}
			
	            			//printf("node added to the tail of job queue is %d\n",temp_node->pid);
					(last)->next = temp_node;
					(last) = temp_node;
				}

			
                     }
		  
		
			current = current->next;
		}	


}
void delete_node_rr(struct RRQ_node **rr_head, int id)
{

	struct RRQ_node  *current_node = *rr_head;
        //struct job_Q *prev = curr_node;
	struct RRQ_node *previous1 = NULL;
	struct RRQ_node *temp1 = NULL; 
	
       	
	while (current_node != NULL) {


    		   if (id == current_node->pid)
	           {
			
			   temp1 = current_node;
			   if (current_node == *rr_head)
			   
		          *rr_head = current_node->next;
			   

			   if (previous1)
				   previous1->next = temp1->next;

			   current_node = current_node->next;
			   free (temp1);
		   }

		   else
		   {
		   	previous1 = current_node;
			current_node = current_node->next;
		   }


	}

}
void  delete_jobQnode_rr(struct rrjob_Q **rrjobQ_head,int id)
{

	struct rrjob_Q  *current_jobnode = *rrjobQ_head;
        //struct job_Q *prev = curr_node;
	struct rrjob_Q *previous2 = NULL;
	struct rrjob_Q *temp2 = NULL; 
	
       	
	while (current_jobnode != NULL) {


    		   if (id == current_jobnode->pid)
	           {
			
			   temp2 = current_jobnode;
			   if (current_jobnode == *rrjobQ_head)
			   
		          *rrjobQ_head = current_jobnode->next;
			   

			   if (previous2)
				   previous2->next = temp2->next;

			   current_jobnode = current_jobnode->next;
			   free (temp2);
		   }

		   else
		   {
		   	previous2 = current_jobnode;
			current_jobnode = current_jobnode->next;
		   }


	}

}
int isempty_rr(struct RRQ_node **rr_head)
{
	if(*rr_head==NULL)
		return 1;
	else
		return 0;
}

/*to get the arrival time*/
int get_arrivaltime_rr(int id,struct  RRQ_node **rr_head)
{

	struct  RRQ_node *current = *rr_head;

	while(current!=NULL)
	{
		if(current->pid == id)
		{
			return current->arrival;
		}

		else
		{
			current = current->next;
		}
	}
}
void add_arrived_node_rr(int time,struct robin_Q **rr_node,struct RRQ_node **rr_head)
{

  //struct job_Q *temp_node = (struct job_Q*) malloc ( sizeof (struct job_Q));
	struct robin_Q *temp_node = NULL;
	struct RRQ_node *current = *rr_head;
       
	while(current!= NULL)
	{
		if(current->arrival == time)
		{

		                temp_node = calloc (1, sizeof (*temp_node));	      
		           	temp_node->pid = current-> pid;
				temp_node->burst_time = current->burst_time;
				temp_node->priority = current->priority;    
				if(*rr_node==NULL)
				{
	                              	
					*rr_node = temp_node;
					(*rr_node)->next = NULL;
					//last = *jobQ_last;
					
				}
	



				else
				{
	
					struct robin_Q *last_rrnode  = *rr_node;
					while(last_rrnode->next!=NULL)
					{
						last_rrnode = last_rrnode->next;
					}
			
					
					(last_rrnode)->next = temp_node;
					last_rrnode = temp_node;
				}

			
                     }

		  
		
			current = current->next;
		}

	
}

void add_preempted_node_rr(struct robin_Q **rr_node,int id, int burst)
{

  //struct job_Q *temp_node = (struct job_Q*) malloc ( sizeof (struct job_Q));
	struct robin_Q *temp_node = NULL;
	//struct run_queue *current = rr_run_Q;
       
		                temp_node = calloc (1, sizeof (*temp_node));
				      
		           	temp_node->pid =  id;
				temp_node->burst_time = burst;
				//temp_node->priority = current->priority;
				
		                
				if(*rr_node==NULL)
				{
	                              	
					*rr_node = temp_node;
					
				
					
				}

			  else
		     		{


		
					struct robin_Q *last = *rr_node;
					while(last->next!=NULL)
					{
						last = last->next;
					}
			
	         			(last)->next = temp_node;
					(last) = temp_node;
				}


}


void load_process_rr(struct robin_Q **rr_node,struct run_queue **rr_run_Q)  
{

	struct robin_Q *curr_node = *rr_node;



	 //load the process from robin queue and delete it

	if(curr_node!=NULL)
	{

                 (*rr_run_Q)->id = curr_node->pid;
	         (*rr_run_Q)->burst_time = curr_node->burst_time;	  
		
			
	         *rr_node = curr_node->next;		

	}

}
void display_rrqueue(struct robin_Q **rr_node,int new_load)
{

	struct robin_Q *curr_node = *rr_node;


	while(curr_node->next!=NULL)
	{


		printf("process %d with burst_time %d\t->", curr_node->pid,curr_node->burst_time);
	        curr_node = curr_node->next;
		
	}

	if(curr_node!=NULL)
	printf("process %d with burst time %d\n",curr_node->pid,curr_node->burst_time);

}


void insert_node_stcf(struct stcfQ_node **stcf_head, struct Process_info proc)
{
	struct  stcfQ_node *temp = (struct stcfQ_node*)calloc(1,sizeof(struct stcfQ_node));

	temp->pid = proc.id;
	temp->burst_time = proc.burst;
	temp->priority = proc.priority;
	temp->arrival = proc.arrival;
       
	if(*stcf_head==NULL)
	{
		*stcf_head = temp;
		stcf_last = temp;
	
	}
	else
	{
		
	

		stcf_last->next = temp;
		stcf_last = temp;
	}
}


void display_queue_stcf(struct stcfQ_node **head)
{
	struct stcfQ_node *current = *head;
	while(current!=NULL)
	{
		printf("Process id is %d and  Burst time is %d\n",current->pid,current->burst_time);
		current = current->next;
	}
}
/* function to insert a new_node in a list. Note that this
  function expects a pointer to head_ref as this can modify the
  head of the input linked list (similar to push())*/
void sortedInsert_stcf(struct stcfjob_Q** head_ref, struct stcfjob_Q* new_node)
{
    struct stcfjob_Q* current;
    /* Special case for the head end */
    if (*head_ref == NULL || (*head_ref)->burst_time >= new_node->burst_time)
    {
        new_node->next = *head_ref;
        *head_ref = new_node;
    }
    else
    {
        /* Locate the node before the point of insertion */
        current = *head_ref;
        while (current->next!=NULL &&
               current->next->burst_time < new_node->burst_time)
        {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
}

void display_jobqueue_stcf(struct stcfjob_Q **head_ref)
{



       
    struct stcfjob_Q *current;

   // Initialize sorted linked list
    struct stcfjob_Q *sorted = NULL;
 
    // Traverse the given linked list and insert every
    // node to sorted
    current = *head_ref;
    while (current != NULL)
    {
          struct stcfjob_Q *next = current->next;

        // insert current in sorted linked list
         sortedInsert_stcf(&sorted, current);
	 current = next;
 
     }
 
 
    // Update head_ref to point to sorted linked list
    *head_ref = sorted;


      
	printf("Ready queue:\n");
	current = *head_ref;
	while(current!=NULL && current->next!=NULL)
	{
		printf("%d -> ",current->pid);
		current = current->next;
	}

	if(current!=NULL)
	printf("%d \n", current->pid);
}
int isMinBurst(int burst_time,struct stcfjob_Q* stcfjobQ_head)
{

	int min =  burst_time;

	struct stcfjob_Q* curr_node = stcfjobQ_head;
	 // Check loop while node not equal to NULL
   	 while (curr_node != NULL) {

    		   if (min > curr_node->burst_time)
		   {
			   return 0;
		    }

		   else
			   curr_node = curr_node->next;
          }
	return 1;
}
void addnode_at_arrival_stcf(int time,struct stcfjob_Q **stcfjobQ_head,struct stcfQ_node **stcf_head)
{

  //struct job_Q *temp_node = (struct job_Q*) malloc ( sizeof (struct job_Q));
	struct stcfjob_Q *temp_node = NULL;
	struct stcfQ_node *current = *stcf_head;
       
	while(current!= NULL)
	{
		if(current->arrival == time)
		{


			       
			       //new_member = 1;


		                temp_node = calloc (1, sizeof (*temp_node));
				      
		           	temp_node->pid = current-> pid;
				temp_node->burst_time = current->burst_time;
				temp_node->priority = current->priority;
				
		                
				if(*stcfjobQ_head==NULL)
				{
	                              	
					*stcfjobQ_head = temp_node;
					
					//last = *jobQ_last;
					
				}
				else
				{

					struct stcfjob_Q *last = *stcfjobQ_head;
					while(last->next!=NULL)
					{
						last = last->next;
					}
			
	            			//printf("node added to the tail of job queue is %d\n",temp_node->pid);
					(last)->next = temp_node;
					(last) = temp_node;
				}


			if(isMinBurst(temp_node->burst_time,*stcfjobQ_head) == 1)
				new_member = 1;
			else
				new_member = 0;


                     }

		
			current = current->next;
		}




}

void delete_node_stcf(struct stcfQ_node **stcf_head, int id)
{

	struct stcfQ_node  *current_node = *stcf_head;
        //struct job_Q *prev = curr_node;
	struct stcfQ_node *previous1 = NULL;
	struct stcfQ_node *temp1 = NULL; 
	       
	while (current_node != NULL) {


    		   if (id == current_node->pid)
	           {
			
			   temp1 = current_node;
			   if (current_node == *stcf_head)
			   
				   *stcf_head = current_node->next;
			   

			   if (previous1)
				   previous1->next = temp1->next;

			   current_node = current_node->next;
			   free (temp1);
		   }

		   else
		   {
		   	previous1 = current_node;
			current_node = current_node->next;
		   }


	}

}

int isempty_stcf(struct stcfQ_node **stcf_head)
{
	if(*stcf_head==NULL)
		return 1;
	else
		return 0;
}
void load_process_stcf(struct run_queue *stcf_run_Q, struct stcfjob_Q **stcfjobQ_head)  
{

	struct stcfjob_Q *curr_node = *stcfjobQ_head;

	int min =  10000;
	struct stcfjob_Q *tmp = NULL;

	 // Check loop while node not equal to NULL
   	 while (curr_node != NULL) {

    		   if (min > curr_node->burst_time)
            	   min =  curr_node->burst_time;
	         
	//	   printf("The minimum priority is %d \n",min);
		  
        	   curr_node = curr_node->next;
          }
	

	 //load the process with min priority number to CPU and delete it from the job queue

	curr_node = *stcfjobQ_head;
        //struct job_Q *prev = curr_node;
	struct stcfjob_Q *prev = NULL;

	int rem_node;
	 while (curr_node != NULL) {


    		   if(min == curr_node->burst_time)
	           {

			   rem_node = curr_node->pid;
			   break;

	           }

		   curr_node = curr_node->next;
	
		 }

	 curr_node = *stcfjobQ_head;
	 while(curr_node!=NULL)
	{

		         if(rem_node == curr_node->pid)
		         {
			  // printf("The removed node from the job queue is %d \n", curr_node->pid);

                          stcf_run_Q->id = curr_node->pid;
			   stcf_run_Q->burst_time = curr_node->burst_time;

			   tmp = curr_node;
			   if (curr_node == *stcfjobQ_head)
			   
				   *stcfjobQ_head = curr_node->next;
			   

			   if (prev)
				   prev->next = tmp->next;

			   curr_node = curr_node->next;
			   free (tmp);
		   }

		   else
		   {
		   	prev = curr_node;
			curr_node = curr_node->next;
		   }


	}

}
void  delete_jobQnode_stcf(struct stcfjob_Q **stcfjobQ_head,int id)
{

	struct stcfjob_Q  *current_jobnode = *stcfjobQ_head;
        //struct job_Q *prev = curr_node;
	struct stcfjob_Q *previous2 = NULL;
	struct stcfjob_Q *temp2 = NULL; 
	
       	
	while (current_jobnode != NULL) {


    		   if (id == current_jobnode->pid)
	           {
			
			  // printf("The deleted node is %d\n", current_jobnode->pid);
			   temp2 = current_jobnode;
			   if (current_jobnode == *stcfjobQ_head)
			   
		          *stcfjobQ_head = current_jobnode->next;
			   

			   if (previous2)
				   previous2->next = temp2->next;

			   current_jobnode = current_jobnode->next;
			   free (temp2);
		   }

		   else
		   {
		   	previous2 = current_jobnode;
			current_jobnode = current_jobnode->next;
		   }


	}

}
void  decrease_bursttime(struct stcfjob_Q **stcfjobQ_head,int id)
{

	struct stcfjob_Q  *current_jobnode = *stcfjobQ_head;
        //struct job_Q *prev = curr_node;

       	
	while (current_jobnode != NULL) {


    		   if (id == current_jobnode->pid)
	           {
			
			   current_jobnode->burst_time = current_jobnode->burst_time-1;
		   }

		   
		   			current_jobnode = current_jobnode->next;
		   


	}

}
void add_preempted_node_stcf(struct stcfjob_Q **stcfjobQ_head,struct run_queue *stcf_run_Q)
{

  //struct job_Q *temp_node = (struct job_Q*) malloc ( sizeof (struct job_Q));
	struct stcfjob_Q *temp_node = NULL;
	struct run_queue *current = stcf_run_Q;
       
		                temp_node = calloc (1, sizeof (*temp_node));
				      
		           	temp_node->pid = current-> id;
				temp_node->burst_time = current->burst_time;
				//temp_node->priority = current->priority;
				
		                
				if(*stcfjobQ_head==NULL)
				{
	                              	
					*stcfjobQ_head = temp_node;
														
				}
				else
		     		{


		
					struct stcfjob_Q *last = *stcfjobQ_head;
					while(last->next!=NULL)
					{
						last = last->next;
					}
			
	         			(last)->next = temp_node;
					(last) = temp_node;
				}

     struct stcfjob_Q *current_node;

   // Initialize sorted linked list
    struct stcfjob_Q *sorted = NULL;
 
    // Traverse the given linked list and insert every
    // node to sorted
    current_node = *stcfjobQ_head;
    while (current_node != NULL)
    {
          struct stcfjob_Q *next = current_node->next;

        // insert current in sorted linked list
         sortedInsert_stcf(&sorted, current_node);
	 current_node = next;
 
     }
 
		
	 
    // Update head_ref to point to sorted linked list
    *stcfjobQ_head = sorted;




}
/*to get the arrival time*/
int get_arrivaltime_stcf(int id,struct  stcfQ_node **head)
{

	struct  stcfQ_node *current = *head;

	while(current!=NULL)
	{
		if(current->pid == id)
		{
			return current->arrival;
		}

		else
		{
			current = current->next;
		}
	}
}


/* function to insert a new_node in a list. Note that this
  function expects a pointer to head_ref as this can modify the
  head of the input linked list (similar to push())*/
void sortedInsert_summ_wait(struct schedule_summary** head_ref, struct schedule_summary* new_node)
{
    struct schedule_summary* current;
    /* Special case for the head end */
    if (*head_ref == NULL || (*head_ref)->wait_time > (new_node)->wait_time)
    {
       (new_node)->next = *head_ref;
        *head_ref =new_node;
    }
    else
    {
        /* Locate the node before the point of insertion */
        current = *head_ref;
        while (current->next!=NULL &&
               current->next->wait_time < (new_node)->wait_time)
        {
            current = current->next;
        }
        (new_node)->next = current->next;
        current->next = new_node;
    }
}


/* function to insert a new_node in a list. Note that this
  function expects a pointer to head_ref as this can modify the
  head of the input linked list (similar to push())*/
void sortedInsert_summ_turnaround(struct schedule_summary** head_ref, struct schedule_summary* new_node)
{
    struct schedule_summary* current;
    /* Special case for the head end */
    if (*head_ref == NULL || (*head_ref)->turn_around_time > (new_node)->turn_around_time)
    {
       (new_node)->next = *head_ref;
        *head_ref =new_node;
    }
    else
    {
        /* Locate the node before the point of insertion */
        current = *head_ref;
        while (current->next!=NULL &&
               current->next->turn_around_time < (new_node)->turn_around_time)
        {
            current = current->next;
        }
        (new_node)->next = current->next;
        current->next = new_node;
    }
}


	
/* function to insert a new_node in a list. Note that this
  function expects a pointer to head_ref as this can modify the
  head of the input linked list (similar to push())*/
void sortedInsert_summ_contextswitch(struct schedule_summary** head_ref, struct schedule_summary* new_node)
{
    struct schedule_summary* current;
    /* Special case for the head end */
    if (*head_ref == NULL || (*head_ref)->context_switch_count > (new_node)->context_switch_count)
    {
       (new_node)->next = *head_ref;
        *head_ref =new_node;
    }
    else
    {
        /* Locate the node before the point of insertion */
        current = *head_ref;
        while (current->next!=NULL &&
               current->next->context_switch_count < (new_node)->context_switch_count)
        {
            current = current->next;
        }
        (new_node)->next = current->next;
        current->next = new_node;
    }
}












